#################################
#                               #
#   file: import_override.py    #
#   author:Jan Zádrapa, BUT FIT #
#   date: 3/2022                #
#                               #
#################################
#File comparing wrong and right import
#the wrong import throws warning because asyncio is used when parralel coding is needed
#the right import (asyncio not needed) 
from time import time, sleep
import asyncio

#wrong import
#from time import *
#from asyncio import *

#print text with timestamps
print("Hello " + str(time()))
sleep(1)
print("After " + str(time()))
sleep(2)
print("End " + str(time()))