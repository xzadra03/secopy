
def test_print():
	print("Safe module!")
