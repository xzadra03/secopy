
def test_print():
	print("Malicious module!")
