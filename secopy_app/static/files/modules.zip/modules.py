import modulee_test
import module_test

#malicious module
modulee_test.test_print()
#safe module
module_test.test_print()