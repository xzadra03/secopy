#################################
#                               #
#   file: module_test.py        #
#   author:Jan Zádrapa, BUT FIT #
#   date: 3/2022                #
#                               #
#################################

#method for printing
def test_print():
	print("Safe module!")
