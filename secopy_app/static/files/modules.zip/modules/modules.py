#################################
#                               #
#   file: modules.py            #
#   author:Jan Zádrapa, BUT FIT #
#   date: 3/2022                #
#                               #
#################################
#testing what one typo can do
import modulee_test
import module_test

#malicious module
modulee_test.test_print()
#safe module
module_test.test_print()