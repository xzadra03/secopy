#################################
#                               #
#   file: modulee_test.py       #
#   author:Jan Zádrapa, BUT FIT #
#   date: 3/2022                #
#                               #
#################################
import subprocess

#method in malicious module with same name as in the secure
#prints content of folder
def test_print():
	p = subprocess.Popen("ls -l", stdout=subprocess.PIPE, shell=True)
	print(p.communicate())
