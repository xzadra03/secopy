/***************************************************/
/
/          file: readme.txt
/          author: Jan Zádrapa, BUT FIT
/          date: 4/2022
/          contact: xzadra03@stud.fit.vutbr.cz
/
/***************************************************/

Pickle module exploit

This simple client/server application written in Python's framework Flask shows that pickle
 should not be used. Application is based on the simple app of David Hamann available here:
  https://davidhamann.de/2020/04/05/exploiting-python-pickle/.
Its main purpose is to reveal data on server-side of the application. It is run locally on 127.0.0.1:5000

How to use:
1. Download this repository
2. In folder Exploits/Pickle download requirements by running:
    $pip3 install -r requirements.txt 
3. In folder Exploits/Pickle/server run flask server:
    $flask run

Server should be running. Try open browser and type 127.0.0.1:5000. It should show error Not found, because this app does not use templates.
4. Go to folder ../Pickle/client and open the pickle_exploit.py
5. In class RCE in method __reduce__() there is variable command which pickles and encrypt desired command which will be executed on the server.
 Try whatever command you want and then run.
    $python3 pickle_exploit.py
Script returns pickled and base64 encrypted command. Copy it (without b'', only the string).
6. With this command you can execute code remotely:
    $curl -d "pickled=yourstringhere" http://127.0.0.1:5000/pickle
In terminal, where server is running you can see that some command was executed (for example all folders are shown after ls -a is executed).
7. Try different commands and enjoy!