#
# file: app.py
# brief: Server-side of pickle exploit application
# date: 4/2022
#Credit goes to:
#https://davidhamann.de/2020/04/05/exploiting-python-pickle/
import pickle
import base64
from flask import Flask, request

app = Flask(__name__)

#server deserializes and then executes the command from RCE method
@app.route("/pickle", methods=["POST"])
def hackme():
    data = base64.urlsafe_b64decode(request.form['pickled'])
    deserialized = pickle.loads(data)

    return '',200