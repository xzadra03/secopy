#################################
#                               #
#   file: file.py               #
#   author:Jan Zádrapa, BUT FIT #
#   date: 3/2022                #
#                               #
#################################
#This is example how to securely create temporary file using tempfile
import tempfile

#create, write, read, close
file = tempfile.TemporaryFile()
file.write(b"This is temporary file")
file.seek(0)
print(file.read())
file.close()


