#!/usr/bin/env python3

################################
#                              #
#  file: trojan_code.py        #
#  author: Jan Zádrapa         #
#  date: 3/2022                #
#                              #
#                              #
################################
#file showing early return due to multi-line comment

#registration form
class Form:
    users = [{"username": "Admin", "password": "admin"}]
    
    '''user wants to login to system'''
    def login(self):
        print("Attempt to login: ")
        check_user = input("Type your username: ")
        check_pass = input("Type your password: ")
    
        ''' print all users for showing that user was registered'''
        print(self.users)
        
        for user in Form.users:
            if check_user == user["username"] and check_pass == user["password"]:
                ''' If it is user in database then login and ⁧''';return
                print("Login succesful")
                '''Login method or something'''
                return
            else:
                pass
            
        print("Unknown credetials!")
                
    
    '''user registration'''
    def register(self):
        print("Please type your username and password: ")
        username = input("New username: ")
        password = input("New password: ")
        
        self.users.append({"username": username, "password": password})
        print("User created successfully!")
    
#creating new user registration 'session'
new_form = Form()
new_form.register()
new_form.login()
print("Program ended.")
