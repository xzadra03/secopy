/***************************************************/
/
/          file: readme.txt
/          author: Jan Zádrapa, BUT FIT
/          date: 4/2022
/          contact: xzadra03@stud.fit.vutbr.cz
/
/***************************************************/

Trojan attack (Comment code execution)
This Python script shows the comment code execution with the help of invisible U+2067 (RLI) character.
It is vulnerability mainly for open-source codes, where can be comment such as the one shown in the script added into code without notice and it can create denial of service by early return or other problems. 

How to use:
1. In folder Exploits/Trojan_attack run:
    $python3 trojan_code.py
2. Enjoy and experiment with the code!